-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: campusdb
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sb_carwash`
--

DROP TABLE IF EXISTS `sb_carwash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sb_carwash` (
  `no` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `address` varchar(150) NOT NULL,
  `sites` int NOT NULL,
  `tel` varchar(45) DEFAULT NULL,
  `time` varchar(45) DEFAULT NULL,
  `img` varchar(45) DEFAULT NULL,
  `lat` varchar(45) DEFAULT NULL,
  `lon` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sb_carwash`
--

LOCK TABLES `sb_carwash` WRITE;
/*!40000 ALTER TABLE `sb_carwash` DISABLE KEYS */;
INSERT INTO `sb_carwash` VALUES (1,'Wash Boot 양평로점','서울특별시 영등포구 양평로22마길 28',8,'02-2205-0110','09:00~00:00','YangPyeong.jpg','37.541143','126.892649'),(2,'Wash Boot 경인로점','서울특별시 영등포구 경인로71길 50',8,'02-2205-0111','09:00~00:00','gyeonginro.jpg','37.514229','126.887869'),(3,'Wash Boot 천왕점','서울특별시 구로구 천왕동 277-15',8,'02-2205-0112','09:00~00:00','cheonwang.jpg','37.481194','126.839686'),(4,'Wash Boot 가제1동점','서울특별시 성동구 성수1가제1동 656-310',8,'02-2205-0113','09:00~00:00','gaje1dong.jpg','37.546654','127.045828'),(5,'Wash Boot 강동성안점','서울특별시 강동구 성내제3동 성안로 46',8,'02-2205-0114','09:00~00:00','kangdongseongan.jpg','37.527834','127.130875'),(6,'Wash Boot 성동마장점','서울특별시 성동구 마장동 775-1',8,'02-2205-0115','09:00~00:00','majang.jpg','37.565412','127.040683'),(7,'Wash Boot 성북종암점','서울특별시 성북구 종암동 8-18',8,'02-2205-0116','09:00~00:00','jongam.JPEG','37.595988','127.038315'),(8,'Wash Boot 은평갈현점','서울특별시 은평구 갈현동 464-22번지',8,'02-2205-0117','09:00~00:00','galhyeon.jpg','37.612577','126.917012'),(9,'Wash Boot 관악봉천점','서울특별시 관악구 봉천동 1538-1',8,'02-2205-0118','09:00~00:00','bongcheon.jpg','37.478301','126.940242'),(10,'Wash Boot 용문점','서울특별시 용산구 용문동 32-18',8,'02-2205-0119','09:00~00:00','yongmoon.JPG','37.539130','126.958742');
/*!40000 ALTER TABLE `sb_carwash` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-13  9:17:37
