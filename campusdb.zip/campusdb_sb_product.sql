-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: campusdb
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sb_product`
--

DROP TABLE IF EXISTS `sb_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sb_product` (
  `product_id` int NOT NULL,
  `name` varchar(50) NOT NULL,
  `price` int NOT NULL,
  `amount` int NOT NULL,
  `img` varchar(45) NOT NULL,
  `category` varchar(20) NOT NULL,
  `description` varchar(150) DEFAULT NULL,
  `rating` int DEFAULT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sb_product`
--

LOCK TABLES `sb_product` WRITE;
/*!40000 ALTER TABLE `sb_product` DISABLE KEYS */;
INSERT INTO `sb_product` VALUES (111,'불스원',20000,20,'bullsone.jpg','차량관리','불스원',2),(122,'티렉스 셀프 10종 세차 패키지',50000,30,'122.jpg','외장','셀프세차의 모든것! 지금 구매하세요',4),(123,'소낙스 익스트림 가죽 클리너',18900,30,'123.jpg','실내','가죽관리는 이 물건으로!',4),(124,'소낙스 실내 세차 3종 세트(실내크리너,유리세정제,가죽보호제)',38000,30,'124.jpg','실내','세 가지 제품을 더 싼 가격으로!',4),(125,'소낙스 실내크리너',22000,30,'125.jpg','실내','차량 실내를 더 깨끗하게',4),(126,'소낙스 유리세정제',14000,30,'126.jpg','실내','앞 유리를 깨끗하게',4),(127,'소낙스 가죽보호제',25400,30,'127.jpg','실내','가죽보호는 이 물건으로!',4),(128,'소낙스 휠크리너',25000,30,'128.jpg','외장','소낙스 휠크리너',4),(129,'차량용 앞유리 매직핸들',5000,100,'129.jpg','차량관리','차량 앞유리 닦는걸 더욱 편하게 해줄 물건',5),(130,'극세사 스폰지 세차장갑',5700,40,'130.jpg','차량관리','세차할때 필수품!',4),(131,'흠집제거 컴파운드',7500,50,'131.jpg','차량관리','컴파운드로는 이만한 물건이 없다',5),(132,'차량 수납함 세차 용품 수납',7500,30,'132.jpg','차량관리','수납함 하나정도는 있으면 좋죠!',5),(200,'타월',100,50,'200.jpg','외장','잘 닦이는 타월',4),(201,'빅사이즈 세차타올',7000,30,'201.jpg','외장','작은 타월로 고생하지 말고 큰 타월로 편하게!',3),(202,'초대형 극세사타올',15000,40,'202.jpg','외장','극세사로 더욱 부드럽게!',5),(203,'림피오 페인트클렌저 도장크리너 500ml',16000,10,'203.jpg','외장','도장면을 깨끗하게 해주는 도장 크리너!',NULL),(204,'스팽글 시크릿 코팅제 퀵디테일러 물왁스 광택왁스 300ml',26000,10,'204.png','외장','스팽클에서 나온 쉽고 빠르게 사용 가능한 왁스!',NULL),(205,'리바이브 IN 레더컨디셔너 가죽코팅제 250ml',29000,10,'205.png','실내','가죽관리는 이 물건으로!',NULL),(206,'라보코스메티카 실내 가죽 전용 코팅제 더마 실란트 250ml',45000,10,'206.jpg','실내','가죽 관리는 이 물건으로!',NULL),(207,'캉가루 레자왁스 스프레이타입 500ml',5000,10,'207.png','실내','왁스를 스프레이 타입으로 더욱 편하게!',NULL),(208,'불스원샷 스탠다드 연료첨가제 500ml',12000,10,'208.jpg','차량관리','연비를 늘리고 싶다면 연료 첨가제는 필수! 불스원샷에서 출시한 연료 첨가제!',NULL),(209,'불스원 부동액 3L 사계절 동결방지 자동차용품',17000,10,'209.jpg','차량관리','부동액도 역시 불스원샷!',NULL),(210,'불스원샷 경유 트럭버스용 1L디젤 화물차 트럭 버스',21000,10,'210.jpg','차량관리','불스원샷에서 나온 트럭용 첨가제!',NULL);
/*!40000 ALTER TABLE `sb_product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-13  9:17:36
