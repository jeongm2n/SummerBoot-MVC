-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: campusdb
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sb_member`
--

DROP TABLE IF EXISTS `sb_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sb_member` (
  `id` varchar(20) NOT NULL,
  `pwd` varchar(20) NOT NULL,
  `mem_name` varchar(20) NOT NULL,
  `tel` varchar(20) NOT NULL,
  `snssts` varchar(5) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `email_yn` varchar(5) DEFAULT NULL,
  `point` int DEFAULT '0',
  `address` varchar(150) NOT NULL,
  `delivery_addr` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sb_member`
--

LOCK TABLES `sb_member` WRITE;
/*!40000 ALTER TABLE `sb_member` DISABLE KEYS */;
INSERT INTO `sb_member` VALUES ('can','1111','캔','010-1111-1111',NULL,'aaa@naver.com','N',100,'13529/경기 성남시 분당구 판교역로 166 (백현동)/카카오',NULL),('dool','1111','둘리','010-1111-1111','동의','aaa@naver.com','Y',0,'13529/경기 성남시 분당구 판교역로 166 (백현동)/1','42637/대구/달서구/용산동/장산남로 33/1'),('dool11','1111','둘리','010-1111-1111',NULL,'aaa@naver.com','Y',0,'13529/경기 성남시 분당구 판교역로 166 (백현동)/',NULL),('dool2','1111','둘리','010-1111-1111',NULL,'aaa@naver.com','N',0,'13529/경기 성남시 분당구 판교역로 166 (백현동)/',NULL),('hong','1111','둘리','010-1111-1111',NULL,'aaa@naver.com','N',0,'13529/경기 성남시 분당구 판교역로 166 (백현동)/111',NULL),('lee','1111','이재선','010-1111-1111','동의','lee@naver.com','N',0,'13529/경기 성남시 분당구 판교역로 166 (백현동)/',NULL),('lee96','1111','둘리','010-1111-1111',NULL,'aaa@naver.com','N',0,'13529/경기 성남시 분당구 판교역로 166 (백현동)/',NULL),('ryu','1111','류은아','010-1111-1111','동의','ryu@naver.com','N',0,'13529/경기 성남시 분당구 판교역로 166 (백현동)/',NULL),('seo','1111','서정민','010-1111-1111','동의','seo@naver.com','N',0,'42637/대구 달서구 장산남로 33 (용산동, 용산롯데캐슬그랜드)/1','42637/대구/달서구/용산동/장산남로 33 롯데캐슬그랜드아파트/'),('yang','1111','양지민','010-1111-1111','동의','yang@naver.com','N',0,'13529/경기 성남시 분당구 판교역로 166 (백현동)/',NULL);
/*!40000 ALTER TABLE `sb_member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-13  9:17:37
