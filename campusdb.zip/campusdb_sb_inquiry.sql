-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: campusdb
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sb_inquiry`
--

DROP TABLE IF EXISTS `sb_inquiry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sb_inquiry` (
  `q_no` int NOT NULL AUTO_INCREMENT,
  `writer` varchar(45) NOT NULL,
  `category` varchar(45) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` longtext NOT NULL,
  `secret` varchar(45) NOT NULL,
  `ins_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `answer` longtext,
  `answer_date` timestamp NULL DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`q_no`),
  KEY `writer_idx` (`writer`),
  CONSTRAINT `writer` FOREIGN KEY (`writer`) REFERENCES `sb_member` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sb_inquiry`
--

LOCK TABLES `sb_inquiry` WRITE;
/*!40000 ALTER TABLE `sb_inquiry` DISABLE KEYS */;
INSERT INTO `sb_inquiry` VALUES (1,'dool','세차예약','예약 내용 변경하고 싶어요','예약을 했는데 내용을 변경하고 싶습니다','N','2023-08-22 17:01:13','예약 내용 변경은 예약 취소 하신 후에 다시 예약을 하셔야합니다','2023-08-25 21:03:48','답변완료'),(4,'dool','쇼핑취소','상품 주문 취소','주문을 취소/반품하면 바로 환불 받을 수 있나요?','N','2023-08-22 17:12:28','카드사에 따라 환불시기는 다를 수 있습니다','2023-08-30 22:23:47','답변완료'),(16,'seo','쇼핑취소','환불관련문의','환불이 완료되었는지 어디서 확인할 수 있나요??','Y','2023-09-11 07:10:55',NULL,NULL,'답변대기'),(17,'seo','세차예약','예약변경요청','세차 예약한 날짜를 변경하고 싶습니다. 변경버튼이 없는데 어떻게 변경할 수 있나요??','Y','2023-09-11 07:42:56',NULL,NULL,'답변대기'),(18,'yang','기타포인트','포인트적립','예약시 포인트 적립이 얼마나 되는지 궁금합니다!','Y','2023-09-11 07:19:35',NULL,NULL,'답변대기'),(19,'yang','세차예약','세차시간추가','예약한 시간보다 더 오랜 시간 세차를 하게 될 것 같습니다.\r\n혹시 세차하면서 예약시간을 추가할 수 있나요???','Y','2023-09-11 07:57:02',NULL,NULL,'답변대기'),(20,'dool','기타포인트','포인트사용','포인트를 사용해서 결제했는데 사용되지 않고 결제되었습니다! 확인 부탁 드립니다','Y','2023-09-11 07:32:32',NULL,NULL,'답변대기'),(21,'lee','세차취소','예약취소','9월18일 천왕점에 세차 예약을 했습니다!\r\n취소하고 싶은데 가능한가요?','Y','2023-09-11 07:36:50',NULL,NULL,'답변대기'),(22,'dool','쇼핑취소','배송 확인은 어디서 하나요?','배송 확인은 어디서 하나요?','N','2023-09-11 07:37:36','상단에 있는 메뉴바의 사용자 이모티콘을 클릭하시면 주문확인 메뉴가 있습니다! \r\n페이지로 이동하시면 주문 진행 현황이 확인 가능합니다:)','2023-09-11 09:04:21','답변완료'),(23,'ryu','쇼핑배송','주문한 상품과 다른 상품이 배송되었어요.','주문한 상품과 다른 상품이 배송되었어요. 확인 부탁드립니다!','Y','2023-09-11 07:17:14',NULL,NULL,'답변대기'),(24,'ryu','기타포인트','포인트 반환','주문을 취소하면 적립 포인트는 언제 반환되나요?','N','2023-09-11 07:44:05',NULL,NULL,'답변대기'),(25,'can','세차예약','예약 내역은 어디서 확인할 수 있나요??','예약 내역은 어디서 확인할 수 있나요??','N','2023-09-12 00:53:51',NULL,NULL,'답변대기'),(26,'can','세차예약','예약QR코드','예약 후 사용가능한 QR코드는 어디서 확인할 수 있나요?? ','N','2023-09-11 07:50:39','상단에 있는 메뉴바의 사용자 이모티콘을 클릭하시면예약확 메뉴가 있습니다! \r 페이지로 이동하시면 나의 예약현황의 사용전 테이블에서 예약코드를 클릭하시면 QR코드를 확인하실 수 있습니다:)','2023-09-12 04:29:52','답변완료'),(27,'can','기타','체인문의','체인점 모집은 안하시나요?','Y','2023-09-11 07:30:38',NULL,NULL,'답변대기'),(29,'hong','기타','놓고 온 물건이 있어요...','세차하고 물건을 놓고 왔는데 어찌 찾을 수 있을까요..?ㅜ','Y','2023-09-12 05:46:17','예약하신 지점에 전화하셔서 확인해 주세요!\r\n \r\n ※ 분실물에 대한 책임은 회원님께 있으며 WASHBOOT는 고객의 분실물에 대해 책임지지 않습니다','2023-09-12 04:24:09','답변완료');
/*!40000 ALTER TABLE `sb_inquiry` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-13  9:17:37
