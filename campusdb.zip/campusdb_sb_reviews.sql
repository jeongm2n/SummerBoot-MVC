-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: campusdb
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sb_reviews`
--

DROP TABLE IF EXISTS `sb_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sb_reviews` (
  `member_id` varchar(20) NOT NULL,
  `num` int NOT NULL AUTO_INCREMENT,
  `point` decimal(2,1) NOT NULL,
  `img` varchar(45) DEFAULT NULL,
  `contents` varchar(200) NOT NULL,
  `rev_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `product_id` int DEFAULT NULL,
  `carwash_no` int DEFAULT NULL,
  PRIMARY KEY (`num`),
  KEY `member_id3_idx` (`member_id`),
  KEY `product_id_idx` (`product_id`),
  KEY `carwash_id_idx` (`carwash_no`),
  CONSTRAINT `c_no` FOREIGN KEY (`carwash_no`) REFERENCES `sb_carwash` (`no`),
  CONSTRAINT `member_id3` FOREIGN KEY (`member_id`) REFERENCES `sb_member` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `p_id` FOREIGN KEY (`product_id`) REFERENCES `sb_product` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sb_reviews`
--

LOCK TABLES `sb_reviews` WRITE;
/*!40000 ALTER TABLE `sb_reviews` DISABLE KEYS */;
INSERT INTO `sb_reviews` VALUES ('dool',14,5.0,NULL,'또가서 세차하고싶어요~깨끗그자체','2023-09-10 23:43:40',NULL,1),('dool',15,5.0,NULL,'프라이빗하게 세차할 수 있어서 좋네요.','2023-09-10 23:50:45',NULL,3),('dool',16,5.0,NULL,'지인한테 추천받아서 왔는데 베리굿굿굿!','2023-09-10 23:52:05',NULL,6),('dool',17,2.0,NULL,'','2023-09-11 15:27:00',NULL,9),('dool',18,4.0,NULL,'저여기 단골이에요','2023-09-11 19:34:10',NULL,2),('dool',19,5.0,NULL,'깨끗해서 자주옵니다 ㅎㅎ','2023-09-11 19:34:24',NULL,1),('dool',20,5.0,NULL,'우리동네서 최고 좋은 세차장!','2023-09-11 19:34:43',NULL,8),('dool',21,5.0,NULL,'오늘만 두번가서 세차했어요 ㅋ','2023-09-11 19:36:37',NULL,7);
/*!40000 ALTER TABLE `sb_reviews` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-13  9:17:36
